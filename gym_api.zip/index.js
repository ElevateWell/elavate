// server.js
const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST", "PUT", "DELETE"]
  }
});

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('join', (data) => {
    socket.join(data.roomId); // Join the room
    console.log(`User ${socket.id} joined Room ${data.roomId} with username: ${data.username}`);
  });

  socket.on('offer', (data) => {
    // Broadcast offer to everyone in the room
    io.to(data.roomId).emit('offer', data);
  });

  socket.on('answer', (data) => {
    // Broadcast answer to everyone in the room
    io.to(data.roomId).emit('answer', data);
  });

  socket.on('ice-candidate', (data) => {
    // Broadcast ice-candidate to everyone in the room
    io.to(data.roomId).emit('ice-candidate', data);
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
