import { Route, Routes } from 'react-router-dom';
import './App.css';
import Meet from './components/common/Authentication';


function App() {
  return (
 <Routes>
  <Route path='/' element={<Meet/>}/>
 </Routes>
  );
}

export default App;
