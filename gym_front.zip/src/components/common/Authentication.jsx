// Meet.js
import React, { useEffect, useRef, useState } from 'react';
import io from 'socket.io-client';
import Peer from 'simple-peer';

const Meet = () => {
  const [myStream, setMyStream] = useState(null);
  const [peers, setPeers] = useState([]);
  const [username, setUsername] = useState('');
  const [roomId, setRoomId] = useState('');
  const [callStarted, setCallStarted] = useState(false);

  const myVideoRef = useRef();
  const peersRef = useRef([]);

  const socket = io('http://localhost:5000'); // Replace with your server URL

  useEffect(() => {
    // Get user media (camera and microphone)
    navigator.mediaDevices.getUserMedia({ video: true, audio: true })
      .then((stream) => {
        setMyStream(stream);
        myVideoRef.current.srcObject = stream;

        // Listen for incoming calls
        socket.on('offer', (data) => handleOffer(data, stream));
        socket.on('answer', handleAnswer);
        socket.on('ice-candidate', handleIceCandidate);

        // Notify the server that a user has joined
        socket.emit('join', { username, roomId });
      })
      .catch((error) => console.error('Error accessing media devices:', error));

    // Cleanup on unmount
    return () => {
      socket.disconnect();
    };
  }, [username, roomId]);

  const handleOffer = (data, stream) => {
    const peer = new Peer({ initiator: false, trickle: false, stream });
    peer.signal(data.offer);

    peer.on('signal', (offer) => {
      socket.emit('answer', { answer: offer, to: data.from });
    });

    peer.on('stream', (remoteStream) => {
      // Display remote video stream
      addPeer(peer, remoteStream);
    });

    peer.on('ice-candidate', (iceCandidate) => {
      socket.emit('ice-candidate', { iceCandidate, to: data.from });
    });
  };

  const handleAnswer = (data) => {
    const peer = peersRef.current.find((p) => p.peerID === data.from);
    peer.peer.signal(data.answer);
  };

  const handleIceCandidate = (data) => {
    const peer = peersRef.current.find((p) => p.peerID === data.from);
    peer.peer.signal(data.iceCandidate);
  };

  const addPeer = (peer, stream) => {
    const peerObj = { peerID: peer._id, peer, stream };
    setPeers((peers) => [...peers, peerObj]);
    peersRef.current.push(peerObj);
  };

  const startCall = () => {
    setCallStarted(true);
  
    // Assuming you have a targetUserID variable representing the user you want to call
    const targetUserID = '123'; // Replace with the actual target user ID
  
    // Create a new Peer instance
    const peer = new Peer({ initiator: true, trickle: false, stream: myStream });
  
    // Send offer to the target user
    peer.on('signal', (offer) => {
      socket.emit('offer', { offer, to: targetUserID });
    });
  
    // Handle incoming stream from the target user
    peer.on('stream', (remoteStream) => {
      addPeer(peer, remoteStream);
    });
  
    // Send ice candidate to the target user
    peer.on('ice-candidate', (iceCandidate) => {
      socket.emit('ice-candidate', { iceCandidate, to: targetUserID });
    });
  
    // Store the new peer in the peersRef array
    peersRef.current.push({ peerID: targetUserID, peer, stream: myStream });
  };
  

  return (
    <div>
      <div>
        {!callStarted ? (
          <div>
            <input
              type="text"
              placeholder="Enter your username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <input
              type="text"
              placeholder="Enter room ID"
              value={roomId}
              onChange={(e) => setRoomId(e.target.value)}
            />
            <button onClick={startCall}>Start Call</button>
          </div>
        ) : (
          <div>
         <video ref={myVideoRef} muted autoPlay playsInline style={{ width: '200px', height: '150px' }} />
{peers.map((peer) => (
  <video
    key={peer.peerID}
    autoPlay
    playsInline
    ref={(videoRef) => (videoRef.srcObject = peer.stream)}
    style={{ width: '400px', height: '300px' }}
  />
))}

          </div>
        )}
      </div>
    </div>
  );
};

export default Meet;
